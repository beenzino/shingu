a=[1,2,3,4,5]
a.append(10)
a.append(20)
print(a.pop())
print(a.pop())
print(a.pop(0))
a = ["s","h","i","n","g","u"]
'''b="shingu"
   a=list(b)'''
for i in range(len(a)):
    print(a.pop())

s = set([1,2,3])
s.add(1)
print(s)
s.remove(1)
print(s)
s.update([1,4,5,6,7])
print(s)
s.discard(3)
print(s)
s.clear()
print(s)
