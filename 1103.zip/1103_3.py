a = [5,3,4,1,2]
print(a.index(2))
print(a.count(5))
a.sort()
print(a)
a.reverse()
print(a)
b=sorted(a)
print(b)
