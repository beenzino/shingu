color = ['red','blue','green']
color2 = ['orange','black','white']

print(color+color2)
print(len(color+color2))
color[0] = 'yellow'
print(color*2)
print('blue' in color2)
total_color = color + color2
for each_color in total_color:
    print(each_color)
color.append("white")
color.extend(["black","purple"])
color.insert(0,"orange")
print(color)
color.remove("white")
del color[0]
print(color)

